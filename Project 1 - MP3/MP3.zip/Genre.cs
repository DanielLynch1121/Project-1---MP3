﻿/**
*--------------------------------------------------------------------
* File name: {Genre.cs}
* Project name: {Project 1 - MP3}
*--------------------------------------------------------------------
* Author’s name and email: {Daniel Lynch ynchda@etsu.edu}
* Course-Section: {002}
* Creation Date: {02/02/2023}
* -------------------------------------------------------------------
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1___MP3
{
    public enum Genre
    {
        Rock,
        Pop,
        Jazz,
        Country,
        Classical,
        Lofi,
        Funk,
        Rap,
        Other
    }
}
